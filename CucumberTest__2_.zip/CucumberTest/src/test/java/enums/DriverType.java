package enums;

public enum DriverType {

	FIREFOX,
	CHROME,
	INTERNETEXPLORER
}
