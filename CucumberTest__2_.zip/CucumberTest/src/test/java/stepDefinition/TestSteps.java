package stepDefinition;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import Managers.FileReaderManager;
import Managers.PageObjectManager;
import Managers.WebDriverManager;
import PageObjects.CheckOut;
import PageObjects.HomePage;
import PageObjects.Login;
import PageObjects.MyAccount;
import PageObjects.Products;
import PageObjects.Registration;
import PageObjects.ShoppingCart;
import Utilities.Reports;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dataProvider.ConfigFileReader;


public class TestSteps {
	
	
	WebDriver driver;
	HomePage hmpg;
	MyAccount myAccount;
	Login login;
	Registration registration;
	Products products;
	Reports reports;
	ShoppingCart shoppingCart;
	CheckOut checkOut;
	PageObjectManager pageObjectManager;
	WebDriverManager webDriverManager;
	ConfigFileReader configFileReader = new ConfigFileReader();

	//Hooks to be executed at the start of each scenario for Initializing browser and object instances
	@Before ("@SmokeTest, @RegressionTest")
	public void beforeScenario() {
		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
		pageObjectManager = new PageObjectManager(driver);
		hmpg = pageObjectManager.getHomePage();
		myAccount = pageObjectManager.getMyAccount();
		registration = pageObjectManager.getRegistration();
		login = pageObjectManager.getLogin();
		products = pageObjectManager.getProducts();
		shoppingCart = pageObjectManager.getShoppingCart();
		checkOut = pageObjectManager.getCheckOut();
	}
	
	@Given("^user launches the opencart application$")
	public void user_launches_the_opencart_application() throws Throwable {
	   driver.get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
		//driver.get("http://spezicoe.wipro.com:81/opencart1/");
	   reports = pageObjectManager.getreports();
	   	String title = driver.getTitle();
		assertEquals("OpenCart is not launched successfully", "Your Store", title);		
		reports.addTestLog("OpenCart is launched successfully");	
	 	   
	}

	@When("^user clicks on Register link$")
	public void user_clicks_on_Register_link() throws Throwable {
		 hmpg.user_clicks_Register();
	}
		
	@When("^user enters \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		registration.user_Enters_PersonalDetails(arg1, arg2, arg3, arg4);
	}
	
	@When("^user enters \"([^\"]*)\"$")
	public void user_enters(String arg1) throws Throwable {
		registration.user_Enters_Password(arg1);
	}
	
	@When("^user clicks on Continue button$")
	public void user_clicks_on_Continue_button() throws Throwable {
		registration.user_Selects_Continue();
	}
		
	@Then("^user sees Confirmation message for Account created$")
	public void user_sees_Confirmation_message_for_Account_created() throws Throwable {
		registration.user_Sees_Confirmation();
	   }

	@When("^user clicks on Continue button from MyAccount Page$")
	public void user_clicks_on_Continue_button_from_MyAccount_Page() throws Throwable {
		myAccount.user_Selects_Continue_MyAccount();
	}
	
	@Then("^My Account page is displayed$")
	public void My_Account_page_is_displayed() throws Throwable {
		myAccount.verify_MyAccount_Page();
	}

	@When("^user clicks on Log Out from My Account menu$")
	public void user_clicks_on_Log_Out_from_My_Account_menu() throws Throwable {
		myAccount.user_Selects_LogOut();
	}
	
	
	@Then("^user is successfully logged out$")
	public void user_is_successfully_logged_out() throws Throwable {
		myAccount.user_loggedout();
	}
	
	@When("^user clicks on Login link$")
	public void user_clicks_on_Login_link() throws Throwable {
	    hmpg.user_clicks_Login();
	}

	@When("^user enters \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_enters(String emailAddress, String password) throws Throwable {
	    login.user_Enters_Credentials(emailAddress, password);
	}

	@When("^user clicks on Login button$")
	public void user_clicks_on_Login_button() throws Throwable {
		login.user_Clicks_login();
	}
		
	@When("^user clicks on Edit Account link$")
	public void user_clicks_on_Edit_Account_link() throws Throwable {
	   myAccount.user_clicks_EditAccount();
	}

	@When("^user updates \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void user_updates(String firstName, String lastName, String telephone) throws Throwable {
	   registration.user_updates_PersonalDetails(firstName, lastName, telephone);
	}

	@When("^user clicks on Continue button for Edit$")
	public void user_clicks_on_Continue_button_for_Edit() throws Throwable {
		registration.user_EditMyAccount_Continue();
	}
	@Then("^user sees Confirmation message for Account edited$")
	public void user_sees_Confirmation_message_for_Account_edited() throws Throwable {
	  myAccount.user_Sees_Confirmation_EditAccount();
	}
	
	@When("^user selects Euro from the currency drop down$")
	public void user_selects_Euro_from_the_currency_drop_down() throws Throwable {
	      myAccount.user_Selects_currency_Euro();
	}
		
	@When("^user search for a product \"([^\"]*)\"$")
	public void user_search_for_a_product(String Product) throws Throwable {
		 products.user_Performs_Product_Search(Product);
	}

	
	@When("^user selects Pound Sterling from the currency drop down$")
	public void user_selects_Pound_Sterling_from_the_currency_drop_down() throws Throwable {
		    myAccount.user_Selects_currency_Pound();
	}

	
	@When("^user selects US Dollar from the currency drop down$")
	public void user_selects_US_Dollar_from_the_currency_drop_down() throws Throwable {
		    myAccount.user_Selects_currency_Dollar();
	}

	@Then("^user sees the product currency is displayed in Euro \"([^\"]*)\"$")
	public void user_sees_the_product_currency_is_displayed_in_Euro(String euro) throws Throwable {
	    products.user_verifies_currency(euro);
	}

	@Then("^user sees the product currency is displayed in Pound \"([^\"]*)\"$")
	public void user_sees_the_product_currency_is_displayed_in_Pound(String pound) throws Throwable {
		products.user_verifies_currency(pound);
	}

	@Then("^user sees the product currency is displayed in Dollar \"([^\"]*)\"$")
	public void user_sees_the_product_currency_is_displayed_in_Dollar(String dollar) throws Throwable {
		products.user_verifies_currency(dollar);
	}

	@When("^user selects Show All Desktops from Desktops header bar$")
	public void user_selects_Show_All_Desktops_from_Desktops_header_bar() throws Throwable {
	      hmpg.user_navigates_Desktop();
	}

	@When("^user adds the product \"([^\"]*)\" to cart$")
	public void user_adds_the_product_to_cart(String product) throws Throwable {
	    products.user_Adds_product_ToCart(product);
	    
	}

	@When("^user navigates to Shoping Cart$")
	public void user_navigates_to_Shoping_Cart() throws Throwable {
	   shoppingCart.user_Navigates_ToShoppingCart();
	   
	}

	@Then("^user verifies the product details and price in cart$")
	public void user_verifies_the_product_details_and_price_in_cart() throws Throwable {
		shoppingCart.user_Verifies_CartDetails();
	   
	}

	@When("^user clicks on Checkout button$")
	public void user_clicks_on_Checkout_button() throws Throwable {
		shoppingCart.user_Clicks_CheckOut();
	    
	}

	@When("^user enters Billing details$")
	public void user_enters_Billing_details() throws Throwable {
		checkOut.user_Enters_billingDetails();
	}

	@When("^user enters Delivery details$")
	public void user_enters_Delivery_details() throws Throwable {
		checkOut.user_Enters_DeliveryDetails();
	}

	@When("^user enters Delviery Method$")
	public void user_enters_Delviery_Method() throws Throwable {
		checkOut.user_Enters_DeliveryMethod();
	}

	@When("^user enters Payment Method$")
	public void user_enters_Payment_Method() throws Throwable {
		checkOut.user_Enters_PaymentMethod();
	    
	}

	@When("^user confirms to place the order$")
	public void user_confirms_to_place_the_order() throws Throwable {
		checkOut.user_Confirms_Order();
	}

	@Then("^order is placed successfully$")
	public void order_is_placed_successfully() throws Throwable {
		checkOut.user_Verifies_Order_Confirmation();
	   
	}
	
	//Hooks to be executed at the end  of each scenario for taking screenshots in case of failure and to close browser
	@After ("@SmokeTest, @RegressionTest")
	public void afterScenario(Scenario scenario) {
		if(scenario.isFailed()) {
			reports.addTestLog("failed");
		}
		webDriverManager.closeDriver();
	}
	
	
}
