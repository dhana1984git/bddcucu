package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class MyAccount extends ReusableLibrary{

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
	
	public MyAccount(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}
	
	//locating webElements
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'My Account')]")
	private WebElement lnk_MyAccount;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Logout')]")
	private WebElement lnk_LogOut;
		
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Continue')]")
	private WebElement btn_MyAccountContinue;
	
	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'My Account')]")
	private WebElement txt_verifyMyAccount;
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'You have been logged off your account')]")
	private WebElement txt_verifyLogoutMesg;
	
	@FindBy(how = How.XPATH, using = "//li/a[contains(text(),'Edit Account')]")
	private WebElement lnk_editAccount;
		
	@FindBy(how = How.XPATH, using = "//div[contains(text(),' Success: Your account has been successfully updated.')]")
	private WebElement txt_EditConfirmation;
		
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Currency')]")
	private WebElement lst_CurrencyDropDown;
	
	@FindBy(how = How.XPATH, using = "//li/button[contains(text(),'Euro')]")
	private WebElement lnk_Currency_Euro;
		
	@FindBy(how = How.XPATH, using = "//li/button[contains(text(),'Pound')]")
	private WebElement lnk_Currency_Pound;
	
	@FindBy(how = How.XPATH, using = "//li/button[contains(text(),'Dollar')]")
	private WebElement lnk_Currency_Dollar;
	
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	public void user_Selects_Continue_MyAccount() {
		btn_MyAccountContinue.click();
		reports.addTestLog("My Account - Continue button is clicked successfully");	
	}
	
	public void verify_MyAccount_Page() {
		waitTillElementExists(txt_verifyMyAccount, "My Account");
		txt_verifyMyAccount.isDisplayed();
		reports.addTestLog("My Account Page is displayed successfully");	
	}
	
	public void user_Selects_LogOut() {
		lnk_MyAccount.click();
		lnk_LogOut.click();
		reports.addTestLog("Log Out button is clicked successfully");	
	}
	
	public void user_clicks_EditAccount() {
		waitTillElementExists(lnk_editAccount, "Edit Account");
		clickElement(lnk_editAccount, "Edit Account");
	
		String title = driver.getTitle();
		assertEquals("Register Account page is not displayed successfully", "My Account Information", title);
		reports.addTestLog("Edit Account page is displayed successfully");	
}
	
	public void user_Sees_Confirmation_EditAccount() {
		verifyElementPresent(txt_EditConfirmation,"Success");
		reports.addTestLog("Account is updated successfully");	
	}
	
		
	public void user_Selects_currency_Euro() {
		clickElement(lst_CurrencyDropDown, "Currency - Sub Menu");
		clickElement(lnk_Currency_Euro, "Currency - Euro");
		reports.addTestLog("Currency - Euro is selected successfully");	
	}
	
	public void user_Selects_currency_Pound() {
		clickElement(lst_CurrencyDropDown, "Currency - Sub Menu");
		clickElement(lnk_Currency_Pound, "Currency - Pound");
		reports.addTestLog("Currency - Pound is selected successfully");	
	}
	
	public void user_Selects_currency_Dollar() {
		clickElement(lst_CurrencyDropDown, "Currency - Sub Menu");
		clickElement(lnk_Currency_Dollar, "Currency - Dollar");
		reports.addTestLog("Currency - Dollar is selected successfully");	
	}
	
	public void user_loggedout() {
		txt_verifyLogoutMesg.isDisplayed();		
		reports.addTestLog("User is logged out Successfully");	
	}




}
