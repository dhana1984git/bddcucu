package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class CheckOut extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
		
	public CheckOut(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}

//locating webElements
	@FindBy(how = How.ID, using = "button-payment-address")
	public WebElement btn_billingDetailsContinue;
	
	@FindBy(how = How.ID, using = "button-shipping-address")
	public WebElement btn_DeliveryDetailsContinue;
	
	@FindBy(how = How.ID, using = "button-shipping-method")
	public WebElement btn_DeliveryMethodContinue;
	
	@FindBy(how = How.NAME, using = "agree")
	public WebElement chkbx_CartAgree;
	
	@FindBy(how = How.ID, using = "button-payment-method")
	public WebElement btn_PaymentMethodContinue;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Confirm Order']")
	public WebElement btn_CartDeliveryConfirm;
	
	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Your order has been placed')]")
	public WebElement txtbx_CartDeliveryConfirmMessage;
	

	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	public void user_Enters_billingDetails() {
		clickElement(btn_billingDetailsContinue, "Billing Details - Continue");
		//JExecuterClick(btn_billingDetailsContinue);
		reports.addTestLog("Billing Details are entered successfully");
	}
	
	public void user_Enters_DeliveryDetails() {
		clickElement(btn_DeliveryDetailsContinue, "Delivery Details - Continue");
		//JExecuterClick(btn_DeliveryDetailsContinue);
		reports.addTestLog("Delivery Details are entered successfully");
		
	}
	
	public void user_Enters_DeliveryMethod() {
		clickElement(btn_DeliveryMethodContinue, "Delivery Method - Continue");
		//JExecuterClick(btn_DeliveryMethodContinue);
		reports.addTestLog("Delivery Methods are entered successfully");
	}
	public void user_Enters_PaymentMethod() {
		clickElement(chkbx_CartAgree, "Payment Details - Agress");
		clickElement(btn_PaymentMethodContinue, "Payment Details - Continue");
		//JExecuterClick(chkbx_CartAgree);
		//JExecuterClick(btn_PaymentMethodContinue);
		reports.addTestLog("Payment Details are entered successfully");
	}
	
	public void user_Confirms_Order() {
		clickElement(btn_CartDeliveryConfirm, "Cart Delivery - Confirm");
		//JExecuterClick(btn_CartDeliveryConfirm);
		if(isAlertPresent()) {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			JExecuterClick(btn_CartDeliveryConfirm);
		}
		reports.addTestLog("Order is confirmed successfully");
	}
	
	public void user_Verifies_Order_Confirmation() {
		waitTillElementExists(txtbx_CartDeliveryConfirmMessage, "Your Order has been Placed");
		verifyElementPresent(txtbx_CartDeliveryConfirmMessage, "Success: Product added to shoping Cart Message");
		reports.addTestLog("Order has been placed successfully");
		
	}
}