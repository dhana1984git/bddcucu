package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Managers.PageObjectManager;
import Managers.WebDriverManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class HomePage extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
		
	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}

	//locating webElements
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'My Account')]")
	private WebElement lnk_MyAccount;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Register')]")
	private WebElement lnk_Register;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Login')]")
	private WebElement lnk_Login;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Desktops')]")
	public WebElement lnk_Desktop;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Show All Desktops')]")
	public WebElement lnk_ShowAllDesktop;
	
	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Desktops')]")
	public WebElement txt_VerifyDesktopPage;
	
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	public void user_clicks_Register() {
			waitTillElementExists(lnk_MyAccount, "My Account");
			clickElement(lnk_MyAccount, "My Account");
			clickElement(lnk_Register, "Register");
			
			String title = driver.getTitle();
			assertEquals("Register Account page is not displayed successfully", "Register Account", title);
			reports.addTestLog("Register Account page is displayed successfully");	
	}
	 
	public void user_clicks_Login() {
		waitTillElementExists(lnk_MyAccount, "My Account");
		clickElement(lnk_MyAccount, "My Account");
		clickElement(lnk_Login, "Login");
		
		String title = driver.getTitle();
		assertEquals("Account Login page is not displayed successfully", "Account Login", title);
		reports.addTestLog("Account Login page is displayed successfully");	
	}
	
	public void user_navigates_Desktop() {
		clickElement(lnk_Desktop, "Desktop");
		clickElement(lnk_ShowAllDesktop, "Show All Desktop");
		verifyElementPresent(txt_VerifyDesktopPage, "Desktop Page");
		reports.addTestLog("User is navigated to Desktops product page successfully");	
	}
	
}
