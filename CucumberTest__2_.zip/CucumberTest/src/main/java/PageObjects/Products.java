package PageObjects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.cucumber.listener.Reporter;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;


public class Products extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
		
	public Products(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}

	//locating webElements
	@FindBy(how = How.NAME, using = "search")
	private WebElement txtbx_SearchBox;
	
	@FindBy(how = How.XPATH, using = "//div[@id='search']//button")
	private WebElement btn_Search;
		
	@FindBy(how = How.XPATH, using = "//div[@id='content']/div[3]/div")
	private List<WebElement> lst_totalProducts;

	@FindBy(how = How.XPATH, using = "//div[@id='content']/div[3]/div[1]//p[2]")
	private WebElement lst_product;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'HP LP3065')]")
	public WebElement lnk_HPLap;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Add to Cart')]")
	public WebElement btn_AddToCart;
			
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Success: You have added')]")
	public WebElement txt_VerifyAddedToCart;
	
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	public void user_Performs_Product_Search(String product) {
		waitTillElementExists(txtbx_SearchBox, "Search Box");
		inputValue(txtbx_SearchBox, product, "Product Search");
		clickElement(btn_Search, "Search Button");
		
		String title = driver.getTitle();
		assertEquals("Products are not retrieved successfully", "Search - mac", title);
		reports.addTestLog("Products are retrieved successfully");	
	}

	public void user_verifies_currency(String currency) {
		List <WebElement> elements = lst_totalProducts;
		int size = elements.size();
		System.out.println("List size is:" + size);
		
		for (int i=1; i<=size; i++) {
			String actualcurrency = driver.findElement(By.xpath("//div[@id='content']/div[3]/div["+i+"]//p[2]")).getText();
			if(actualcurrency.contains(currency)) {
				Reporter.addStepLog("Currency value is displayed as: " + currency + " for the prpduct " + i);
				}
		}
		pageScroll(lst_product);
		reports.addTestLog("Currency value is displayed correctly as: " + currency);	
	}
	 
	public void user_Adds_product_ToCart(String product) {
	
		JExecuterClick(lnk_HPLap);
		waitTillElementExists(btn_AddToCart, "Add To Cart");
		driverWait(30);
		String title = driver.getTitle();
		assertEquals(product + " is not retrieved successfully", product, title);
		Reporter.addStepLog(product + " is retrieved successfully");	
		//clickElement(btn_AddToCart, "Add To Cart");
		JExecuterClick(btn_AddToCart);
		//actionsClick(btn_AddToCart, "Add To Cart");
		driverWait(30);
		verifyElementPresent(txt_VerifyAddedToCart, "Success - Added to Shopping Cart");
		reports.addTestLog("Product is added to Shopping Cart Successfully");	
	}
	
	
	
}
