package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class Registration extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
	
	public Registration(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();

	}
	
	
	//locating webElements
	@FindBy(how = How.NAME, using = "firstname")
	private WebElement txtbx_FirstName;
	
	@FindBy(how = How.NAME, using = "lastname")
	private WebElement txtbx_LastName;
	
	@FindBy(how = How.NAME, using = "email")
	private WebElement txtbx_Email;
	
	@FindBy(how = How.NAME, using = "telephone")
	private WebElement txtbx_Telephone;
	
	@FindBy(how = How.NAME, using = "password")
	private WebElement txtbx_Password;
	
	@FindBy(how = How.NAME, using = "confirm")
	private WebElement txtbx_ConfirmPassword;
	
	@FindBy(how = How.NAME, using = "agree")
	private WebElement ckb_Agree;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Continue']")
	private WebElement btn_Continue;
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'Congratulations')]")
	private WebElement txt_Confirmation;
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	
	public void user_Enters_PersonalDetails(String firstName, String lastName, String email, String telephone) {
		inputValue(txtbx_FirstName,firstName, "First Name");
		inputValue(txtbx_LastName,lastName, "Last Name");
		inputValue(txtbx_Email,email, "Email");
		inputValue(txtbx_Telephone,telephone, "Telephone");
		reports.addTestLog("Personal Details are entered successfully");
			
	}
	
	public void user_Enters_Password(String password) {
		inputValue(txtbx_Password,password, "Password");
		inputValue(txtbx_ConfirmPassword,password, "Confirm Password");
		reports.addTestLog("Password Details are entered successfully");	
	}
	
	public void user_Selects_Continue() {
			ckb_Agree.click();
			btn_Continue.click();
			reports.addTestLog("Continue button is clicked successfully");	
	}
	
	public void user_Sees_Confirmation() {
		//String title = driver.getTitle();
		//assertEquals("Account is not created successfully", "Your Account Has Been Created!", title);	
		verifyElementPresent(txt_Confirmation,"Congratulations");
		reports.addTestLog("Account is created successfully");	
	}
	
	public void user_updates_PersonalDetails(String firstName, String lastName,String telephone) {
		inputValue(txtbx_FirstName,firstName, "First Name");
		inputValue(txtbx_LastName,lastName, "Last Name");
		inputValue(txtbx_Telephone,telephone, "Telephone");
		reports.addTestLog("Updated details are entered successfully");
			
	}
	
	public void user_EditMyAccount_Continue() {
		btn_Continue.click();
		reports.addTestLog("Continue button is clicked successfully");	
}
}
