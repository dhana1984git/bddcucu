package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.cucumber.listener.Reporter;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class ShoppingCart extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
	public static String productPrice;
		
	public ShoppingCart(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}

	
	//locating webElements
	@FindBy(how = How.XPATH, using = "//li/h2[contains(text(),'$')]")
	public WebElement txt_Price;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'shopping cart')]")
	public WebElement lnk_ShopCart;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'HP LP3065')]")
	public WebElement lnk_HPLap;
			
	@FindBy(how = How.XPATH, using = "//td[5][contains(text(),'$')]")
	public WebElement txt_CartPrice;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Checkout')]")
	public WebElement btn_CheckOut;
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */
	
	public void user_Navigates_ToShoppingCart() {
		productPrice = txt_Price.getText();
		clickElement(lnk_ShopCart, "Shopping Cart");
		
		String title = driver.getTitle();
		assertEquals("Shopping Cart page is not displayed successfully", "Shopping Cart", title);
		reports.addTestLog("Shopping Cart page is displayed successfully");	
	}
		
	public void user_Verifies_CartDetails() {
		String cartPrice = txt_CartPrice.getText();
		assertEquals("Product Price doesn't matches in the shopping cart", productPrice, cartPrice);
		Reporter.addStepLog("Product Price is displayed correctly in the cart:  " + cartPrice);
		verifyElementPresent(lnk_HPLap, "Cart - Selected Product");
		reports.addTestLog("Shopping Cart details are verified successfully");	
	}
	
	public void user_Clicks_CheckOut() {
		clickElement(btn_CheckOut, "CheckOut");
		String title = driver.getTitle();
		assertEquals("CheckOut page is not displayed successfully", "Checkout", title);
		reports.addTestLog("Checkout Page is displayed successfully");	
	}
	
	
	
	
	
}