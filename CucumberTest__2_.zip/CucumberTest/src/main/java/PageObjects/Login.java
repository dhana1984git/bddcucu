package PageObjects;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Managers.PageObjectManager;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class Login extends ReusableLibrary {

	WebDriver driver;
	Reports reports;
	PageObjectManager pageObjectManager;
		
	public Login(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
		pageObjectManager = new PageObjectManager(driver);
		reports = pageObjectManager.getreports();
	}

	//locating webElements
	@FindBy(how = How.ID, using = "input-email")
	private WebElement txt_EmailAddress;
	
	@FindBy(how = How.ID, using = "input-password")
	private WebElement txt_Password;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Login']")
	private WebElement btn_Login;
	
	/*
	 * Binding methods to above locators
	 * ---------------------------------
	 * ---------------------------------
	 */	
	public void user_Enters_Credentials(String emailAddress, String Password) {
			waitTillElementExists(txt_EmailAddress, "Email Address");
			inputValue(txt_EmailAddress, emailAddress, "Email Address");
			inputValue(txt_Password, Password, "Password");
			reports.addTestLog("Login Credentials are entered successfully");			
	}
	 
	public void user_Clicks_login() {
		clickElement(btn_Login, "Login");
		reports.addTestLog("Login button is clicked successfully");	
	}
	
	
}