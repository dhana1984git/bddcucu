package Managers;

import org.openqa.selenium.WebDriver;

import PageObjects.CheckOut;
import PageObjects.HomePage;
import PageObjects.Login;
import PageObjects.MyAccount;
import PageObjects.Products;
import PageObjects.Registration;
import PageObjects.ShoppingCart;
import SupportLibraries.ReusableLibrary;
import Utilities.Reports;

public class PageObjectManager {

	private WebDriver driver;
	private HomePage homePage;
	private MyAccount myAccount;
	private Login login;
	private Registration registration;
	private Products products;
	private Reports reports;
	private ShoppingCart shoppingCart;
	private CheckOut checkOut;
	private ReusableLibrary reusableLibrary;
	
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}
	
	//returns the instance of HomePage(package: PageObjects)
	public HomePage getHomePage() {
		return(homePage==null)? homePage = new HomePage(driver) : homePage;
	}
	
	//returns the instance of Login(package: PageObjects)
	public Login getLogin() {
		return(login==null)? login = new Login(driver) : login;
	}
	
	//returns the instance of MyAccount(package: PageObjects)
	public MyAccount getMyAccount() {
		return(myAccount==null)? myAccount = new MyAccount(driver) : myAccount;
	}
	
	//returns the instance of Registration(package: PageObjects)
	public Registration getRegistration() {
		return(registration==null)? registration = new Registration(driver) : registration;
	}
	
	//returns the instance of ShoppingCart(package: PageObjects)
	public ShoppingCart getShoppingCart() {
		return(shoppingCart==null)? shoppingCart = new ShoppingCart(driver) : shoppingCart;
	}
	
	//returns the instance of CheckOut(package: PageObjects)
	public CheckOut getCheckOut() {
		return(checkOut==null)? checkOut = new CheckOut(driver) : checkOut;
	}
	
	//returns the instance of Products(package: PageObjects)
		public Products getProducts() {
			return(products==null)? products = new Products(driver) : products;
		}
		
	//returns the instance of Reports(package: Utilities)
	public Reports getreports() {
		return(reports==null)? reports = new Reports(driver) : reports;
	}
		
	
	//returns the instance of ReusableLibrary(package: SuppoerLibraries)
	public ReusableLibrary getReusableLibrary() {
		return(reusableLibrary==null)? reusableLibrary = new ReusableLibrary(driver) : reusableLibrary;
	}


}
